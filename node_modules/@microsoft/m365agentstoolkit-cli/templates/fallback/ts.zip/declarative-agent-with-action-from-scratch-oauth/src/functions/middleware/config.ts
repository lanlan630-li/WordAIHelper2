const config = {
  aadAppClientId: process.env.aadAppClientId,
  aadAppTenantId: process.env.aadAppTenantId,
};

export default config;
